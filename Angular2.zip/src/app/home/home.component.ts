import { Component, OnInit } from '@angular/core';

import { User } from '../_models/index';
import { UserService } from '../_services/index';

@Component({
    templateUrl: 'home.component.html'
})

export class HomeComponent implements OnInit {
    currentUser: User;
    users: User[] = [];

    constructor(private userService: UserService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }

    ngOnInit() {
        this.loadAllUsers();
    }
    dashboardFun(){
        document.getElementById("dashboard-section").style.display="block";
        document.getElementById("team-section").style.display="none";
        document.getElementById("about-section").style.display="none";

    }
    teamFun(){
        document.getElementById("team-section").style.display="block";
        document.getElementById("dashboard-section").style.display="none";
        document.getElementById("about-section").style.display="none";
        console.log("function called");
    }
    demoFun() {
        document.getElementById("about-section").style.display="block";
        document.getElementById("dashboard-section").style.display="none";
        document.getElementById("team-section").style.display="none";
    }
    deleteUser(id: number) {
        this.userService.delete(id).subscribe(() => { this.loadAllUsers() });
    }

    private loadAllUsers() {
        this.userService.getAll().subscribe(users => { this.users = users; });
    }
}